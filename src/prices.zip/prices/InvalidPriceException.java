package prices;

public class InvalidPriceException extends Exception {
    public InvalidPriceException(String msg) {
        super(msg);

    }


}
