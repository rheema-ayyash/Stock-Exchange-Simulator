package prices.product.users;

public class DataValidationException extends Exception {
    public DataValidationException(String msg) {

        super(msg);
    }
}
