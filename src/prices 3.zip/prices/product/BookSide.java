package prices.product;


public enum BookSide {
    BUY, SELL;


}


