package prices.product;

public class InvalidReference extends Exception{
    public InvalidReference(String msg) {
        super(msg);
    }
}
